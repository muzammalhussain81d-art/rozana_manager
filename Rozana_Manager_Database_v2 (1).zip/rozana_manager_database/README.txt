ROZANA MANAGER 2.0 - PostgreSQL DATABASE VERSION

Local test:
1. Install Node.js LTS.
2. Create a PostgreSQL database and set DATABASE_URL.
3. In this folder run: npm install
4. Run: npm start
5. Open http://localhost:3000

Render deployment:
- Create a PostgreSQL database.
- Create a Web Service from this project.
- Build command: npm install
- Start command: npm start
- Add environment variable DATABASE_URL = your PostgreSQL connection string.

The app automatically creates its tables on first start.
Passwords are salted/hashed with Node scrypt. Sessions are stored in PostgreSQL.
For production, add HTTPS, rate limiting, email verification/password reset, backups, CSRF protections as appropriate, and a proper secret/session strategy.
